package com.zillionica.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zillionica.project.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
