package com.zillionica.project.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zillionica.project.entity.Employee;
import com.zillionica.project.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	public Employee saveEmployee(Employee employee)
	{
		employeeRepository.save(employee);
		
		return employee;
		
	}
	
	public List<Employee>getAllEmployee()
	{
		List<Employee> ListEmployee=new ArrayList<Employee>();
		
		employeeRepository.findAll().forEach(l1->ListEmployee.add(l1));
		return ListEmployee;
	}

	public Optional<Employee> employeeById(int empId){
	return 	employeeRepository.findById(empId);
		
		
	}
	
	public void deleteEmployee(int empId){
		employeeRepository.deleteById(empId);
		
	}
	
	public void saveUp(Employee employee) {
		
		employeeRepository.save(employee);
	}
	
}
