package com.zillionica.project.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zillionica.project.entity.Employee;
import com.zillionica.project.service.EmployeeService;


@RestController
@RequestMapping("/api/v1")
public class EmployeeController {
	
	
	@Autowired
	
	private EmployeeService employeeService;
	
	
	@PostMapping("/save")
	public Employee saveEmp(@RequestBody Employee employee)
	{
		employeeService.saveEmployee(employee);
		return employee;
	}
	
	
	@GetMapping("/fetch")
	public List<Employee>getEmployee()
	{
		List<Employee> allEmployee= employeeService.getAllEmployee();
		return allEmployee;
	}
	
	@GetMapping("/fetch_employee/{employeeId}")
	
	public Optional<Employee>getEmployeeById(@PathVariable("employeeId") int empId)
	{
		return employeeService.employeeById(empId);			
	}
	@DeleteMapping("/employee/{employeeId}")
	public void deleteEmp(@PathVariable("employeeId")int empId) {
		
		employeeService.deleteEmployee(empId);
	}
	@PutMapping("/employee")
	public void updateEmpl(@RequestBody Employee employee) {
		employeeService.saveEmployee(employee);
	}
}
